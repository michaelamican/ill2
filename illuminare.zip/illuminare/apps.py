from django.apps import AppConfig


class IlluminaireConfig(AppConfig):
    name = 'illuminare'
